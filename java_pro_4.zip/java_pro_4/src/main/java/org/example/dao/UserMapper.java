package org.example.dao;

import org.example.model.User;
import org.springframework.stereotype.Component;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

@Component
public class UserMapper {

    public List<User> mapToUser(ResultSet resultSet) throws SQLException {
        List<User> users = new ArrayList<>();
        while (resultSet.next()) {
            User user = new User(resultSet.getLong("id"),
                    resultSet.getString("username"));
            users.add(user);
        }
        return users;
    }
}
