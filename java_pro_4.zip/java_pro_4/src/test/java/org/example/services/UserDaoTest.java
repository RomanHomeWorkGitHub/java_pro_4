package org.example.services;

import org.example.dao.UserDao;
import org.example.model.User;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import java.sql.SQLException;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;


class UserDaoTest {
    UserService userService;
    UserDao userDao;

    User usr1 = new User(4L, "Иван4");
    User usr2 = new User(2L, "Иван2");
    User usr3 = new User(3L, "Иван3");

    @BeforeEach
    void setUp() throws SQLException {
        ApplicationContext context = new AnnotationConfigApplicationContext("org.example.*");
        userService = context.getBean(UserService.class);
        userDao = context.getBean(UserDao.class);
        userService = new UserService(userDao);
        userDao.createUser(usr1);
        userDao.createUser(usr2);
        userDao.createUser(usr3);
    }

    @AfterEach
    void clean() throws SQLException {
        userDao.deleteUser(2L);
        userDao.deleteUser(3L);
        userDao.deleteUser(4L);
        userDao.deleteUser(1L);
    }

    @Test
    void getUsers() throws SQLException {
        List<User> users = userService.getUsers();
        assertEquals(3, users.size());
        assertEquals(4L, users.get(0).getId());
        assertEquals("Иван4", users.get(0).getUsername());
        assertEquals(2L, users.get(1).getId());
        assertEquals("Иван2", users.get(1).getUsername());
        assertEquals(3L, users.get(2).getId());
        assertEquals("Иван3", users.get(2).getUsername());
    }

    @Test
    void getUserById() throws SQLException {
        User user = userService.getUserById(4L);
        assertEquals(4, user.getId());
        assertEquals("Иван4", user.getUsername());

    }

    @Test
    void createUser() throws SQLException {
        userService.createUser(new User(1L, "Иван1"));
        User user = userService.getUserById(1L);
        assertEquals(1, user.getId());
        assertEquals("Иван1", user.getUsername());
    }

    @Test
    void updateUser() throws SQLException {
        userService.createUser(new User(1L, "Иван1"));
        User user = userService.getUserById(1L);
        
        userService.updateUser(new User(1L, "Иван5"));
        User userUpdate = userService.getUserById(1L);
        assertEquals(user.getId(), userUpdate.getId());
        assertNotEquals(user.getUsername(), userUpdate.getUsername());
        assertEquals("Иван5", userUpdate.getUsername());
    }

    @Test
    void deleteUser() throws SQLException {
        int listSize = userService.getUsers().size();
        userService.deleteUser(2L);
        assertEquals(listSize - 1, userService.getUsers().size());
    }
}